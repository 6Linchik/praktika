import AuthService from "../../services/authService.js";
import HousesService from "../../services/housesService.js";
import { STORAGE_KEYS, load, save } from "../../services/storage.js";

const refs = {
  mainForm: document.getElementById("mainForm"),
};

const housesController = new HousesService();
const authController = new AuthService();

refs.mainForm.addEventListener("submit", handleSubmit);

async function handleSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget

  const formData = new FormData(form);
  const newHouse = Object.fromEntries(formData.entries());

  newHouse.email = load(STORAGE_KEYS.email);

  try {
    const res = await housesController.addNewHouse(newHouse);
    if (res.status === 200) {
      Notiflix.Notify.success("Added!");

      save(STORAGE_KEYS.houseId, res.data._id);

      await authController.pushNewHouse(newHouse.email, res.data._id);

      //location.href = "../dateFormPage/dateFormPage.html";

      const efficiency = finalCalculate(form)
      console.log(efficiency)
      save("efficiency", efficiency)

       location.href = "../resultPage/resultPage.html";

    }
  } catch (err) {
    console.log(err);
    Notiflix.Notify.failure(err.response.data.message);
  }
}


//! ===========


function finalCalculate(form) {

  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());

  // Отримання числових значень з форми
  const floorArea = parseFloat(data.roomArea);
  const windowArea = parseFloat(data.windowsArea);
  const roofArea = parseFloat(data.roofArea);
  const wallsLength = parseFloat(data.outsideWallsLength);
  const ceilingHeight = parseFloat(data.cellingHeight);
  const numberOfFloors = parseInt(data.floorsAmount);
  const costmonth = parseInt(data.costmonth);
  // const basementArea = parseFloat(data.basementArea);

  // Логічні коефіцієнти для різних параметрів
  const fundamentTypeCoefficient = {
    'Стрічковий': 1.0,
    'Пальовий': 0.9,
    'Пальово-стрічковий': 1.1,
    'Плитний': 1.2,
    'Монолітний': 1.3
  }[data.fundamentType];

  const windowsGlassTypeCoefficient = {
    'Просте скло': 1.0,
    'Подвійне скло без покриття': 0.8,
    'подвійне скло з покриттям (HR)': 0.6,
    'HR+': 0.5,
    'HR++': 0.4,
    'Потрійне скло HR': 0.3
  }[data.windowsGlassType];

  const windowsFrameTypeCoefficient = {
    'Дерево': 1.0,
    '3-х камерний металопластик': 0.5,
    '2-х камерний металопластик': 0.7
  }[data.windowsFrameType];

  const roofTypeCoefficient = {
    'металева покрівля': 1.0,
    'керамічна черепиця': 0.9,
    'бетонна черепиця': 0.8,
    'шифер': 1.1,
    'Пластикові композитні матеріали': 1.2,
    'Асфальтові покрівельні матеріали': 1.3,
    'Сланцеві плити': 0.7,
    'Полімерні покрівельні плівки': 0.6
  }[data.roofType];

  const roofInsulationTypeCoefficient = {
    'ні': 1.0,
    'скло/мінеральна вата': 0.8,
    'пластівціскло/мінеральної вати': 0.7,
    'пінополістирол': 0.6,
    'жорсткий пінополіуретан': 0.5,
    'жорстка/тверда піна з пінополіуретану': 0.4,
    'фенолформальдегід резолу': 0.3,
    'комірчасте скло': 0.2,
    'деревна шерсть': 0.1,
    'деревні волокна': 0.1,
    'спучений перліт': 0.1
  }[data.roofInsulationType];

  const outsideWallsTypeCoefficient = {
    'цегла керамічна повнотіла': 1.0,
    'керамічний блок 2nf': 0.9,
    'силікатна цегла': 0.8,
    'бетон': 1.1,
    'газоблок': 0.7,
    'моноліт із газобетону': 0.6,
    'піноблок': 0.5,
    'моноліт із пінобетону': 0.4,
    'каркасно-щитові': 0.3
  }[data.outsideWallsType];

  const outsideWallsInsulationCoefficient = {
    'ні': 1.0,
    'скло/мінеральна вата': 0.8,
    'пластівціскло/мінеральної вати': 0.7,
    'пінополістирол': 0.6,
    'жорсткий пінополіуретан': 0.5,
    'жорстка/тверда піна з пінополіуретану': 0.4,
    'фенолформальдегід резолу': 0.3,
    'комірчасте скло': 0.2,
    'деревна шерсть': 0.1,
    'деревні волокна': 0.1,
    'спучений перліт': 0.1
  }[data.outsideWallsInsulation];

  // Обчислення об'єму будинку
  const houseVolume = floorArea * ceilingHeight * numberOfFloors;

  // Обчислення площі зовнішніх стін
  const wallArea = wallsLength * ceilingHeight * numberOfFloors;

  // Приклад обчислення втрат тепла (спрощений варіант)
  //125-...
  const heatLoss = (wallArea + windowArea * windowsGlassTypeCoefficient + roofArea * roofTypeCoefficient) * 0.5
    * fundamentTypeCoefficient * windowsFrameTypeCoefficient * roofInsulationTypeCoefficient
    * outsideWallsTypeCoefficient * outsideWallsInsulationCoefficient;

  // Розрахунок енергоефективності
  const energyEfficiency = houseVolume / (110-heatLoss);
  
  // console.log(`Об'єм будинку: ${houseVolume} м³`);
  // console.log(`Втрати тепла: ${heatLoss} Вт`);
  // console.log(`Енергоефективність: ${energyEfficiency} м³/Вт`);

  // alert(`Енергоефективність будинку: ${energyEfficiency.toFixed(2)} м³/Вт`);

  // return { houseVolume, heatLoss, energyEfficiency }
  return { heatLoss , energyEfficiency, floorArea, windowArea, roofArea,  wallsLength, ceilingHeight, numberOfFloors}
};
