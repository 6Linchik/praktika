import sendGPTMessage from "../../services/chatGPTService.js";
import { load, STORAGE_KEYS } from "../../services/storage.js";

const refs = {
  // livingSpace: document.getElementById("livingSpace"),
  // area: document.getElementById("area"),
  // year: document.getElementById("year"),
  // heatingType: document.getElementById("heatingType"),
  // residents: document.getElementById("residents"),
  // roomTemperature: document.getElementById("roomTemperature"),
  heatLoss: document.getElementById("heatLoss"),
  energyEfficiency: document.getElementById("energyEfficiency"),
};

const formData = load(STORAGE_KEYS.formData);

fillMarkupWithData(formData);

console.log(formData);

async function fillMarkupWithData(formData) {
  // refs.livingSpace.textContent = formData.livingSpace;
  // refs.area.textContent = formData.area;
  // refs.year.textContent = formData.year;
  // refs.heatingType.textContent = formData.heatingType;
  // refs.residents.textContent = formData.residents;
  // refs.roomTemperature.textContent = formData.roomTemperature;

  const efficiency = load("efficiency")
  console.log(efficiency);
  console.log(efficiency.heatLoss);
  const answers = await sendGPTMessage(`Є будинок з такими параметрами:${JSON.stringify(efficiency)} що можна зробити для покращення енергоефективності?`)
  console.log(answers);
  console.log(refs.heatLoss);
  refs.heatLoss.textContent=efficiency.heatLoss.toFixed(2);  


  const gptAnswer = document.getElementById("gptAnswer")
  const gptContinue = document.getElementById("gptContinue")

  gptAnswer.textContent  = answers[answers.length -1].content

  gptContinue.addEventListener("click", async () => {
  const answers = await sendGPTMessage("враховуючи свої попередні відповіді продовж рекомендації")
  gptAnswer.textContent += answers[answers.length -1].content

  })

  let img=document.querySelector("img");
  //0-20, 21-40, 41-60, 61-80, 81-100, 100+
  if (efficiency.heatLoss<=20) img.src="../../images/a-plus.png";
  else if (efficiency.heatLoss>20 && efficiency.heatLoss<=40) img.src="../../images/a.png";
  else if (efficiency.heatLoss>41 && efficiency.heatLoss<=60) img.src="../../images/b.png";
  else if (efficiency.heatLoss>61 && efficiency.heatLoss<=80) img.src="../../images/c.png";
  else if (efficiency.heatLoss>81 && efficiency.heatLoss<=100) img.src="../../images/d.png";
  else img.src="../../images/e.png"

  
}
