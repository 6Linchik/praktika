const API_KEY = "sk-proj-XJ4Wl5NYTYAhav0U3ueeT3BlbkFJhFnyRCoktdEN5tzJ4YsG"

let messages = [];

export default async function sendGPTMessage(userInput) {

    messages.push({ role: "user", content: userInput });

    await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: messages,
            max_tokens: 150,
            n: 1,
            stop: null,
            temperature: 0.7,
        }),
    })
        .then((response) => response.json())
        .then((data) => {
            console.log(data);
            const botResponse = data.choices[0].message.content.trim();


            messages.push({ role: "assistant", content: botResponse });

        })
        .catch((error) => console.error("Error:", error));

    return messages
}